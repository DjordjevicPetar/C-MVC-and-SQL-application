﻿using A17.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace A17.Controllers
{
    public class IspitController : Controller
    {
        static List<Pitanje> test = new List<Pitanje>();
        // GET: Ispit
        public ActionResult Prikaz()
        {
            test.Clear();
            DataSet ds = new DataSet();
            using (StreamReader reader = new StreamReader(Server.MapPath("~/Xml/Pitanja.xml")))
            {
                ds.ReadXml(reader);
            }
            foreach (DataRow row in ds.Tables[0].Rows)
            {
                test.Add(new Pitanje(row));
            }
            return View(test);
        }

        [HttpPost]
        public ActionResult Resenja(FormCollection collection)
        {
            foreach (var key in collection.AllKeys)
            {
                string k = collection[key];
            }
            for (int i = 1; i < test.Count + 1; i++)
            {
                test[i].Odgovori(collection["Odgovor " + i.ToString()].ToString());
            }
            return View(test);
        }
    }
}