﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace A17.Models
{
    public class Pitanje
    {
        public int redni_broj { get; set; }
        public string pitanje { get; set; }
        public string[] odgovori { get; set; }
        public string tacan_odgovor { get; set; }
        public string odgovoreno { get; set; }
        public Pitanje(DataRow row)
        {
            redni_broj = Convert.ToInt32(row["Rbr"]);
            pitanje = row["Pitanje"].ToString();
            odgovori = new string[4];
            odgovori[0] = row["Odgovor1"].ToString();
            odgovori[1] = row["Odgovor2"].ToString();
            odgovori[2] = row["Odgovor3"].ToString();
            odgovori[3] = row["Odgovor4"].ToString();
            tacan_odgovor = row["Resenje"].ToString();
        }
        public string Odgovori(string dat_odgovor)
        {
            odgovoreno = dat_odgovor;
            return "Proslo " + dat_odgovor;
        }
    }
}