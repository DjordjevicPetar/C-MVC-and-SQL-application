﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace A18.Models
{
    public class Prognoza
    {
        public string mesto { get; set; }
        public string naziv_mesta { get; set; }
        public int min_temperatura { get; set; }
        public int max_temperatura { get; set; }
        public string vreme { get; set; }
        public Prognoza(DataRow row)
        {
            mesto = row["Mesto"].ToString();
            naziv_mesta = row["NazivMesta"].ToString();
            min_temperatura = Convert.ToInt32(row["MinTemperatura"]);
            max_temperatura = Convert.ToInt32(row["MaxTemperatura"]);
            vreme = row["Vreme"].ToString();
        }
    }
}