﻿using A18.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace A18.Controllers
{
    public class PrikazController : Controller
    {
        static List<Prognoza> prognoze = new List<Prognoza>();
        // GET: Prikaz
        public ActionResult Izbor()
        {
            DataSet data_set = new DataSet();
            HashSet<string> mesta = new HashSet<string>();
            using (StreamReader reader = new StreamReader(Server.MapPath("~/Xml_Files/Prognoza.xml")))
            {
                data_set.ReadXml(reader);
            }
            foreach (DataRow row in data_set.Tables[0].Rows)
            {
                prognoze.Add(new Prognoza(row));
                mesta.Add(row[1].ToString());
            }
            return View(mesta);
        }

        [HttpPost]
        public ActionResult Details(FormCollection collection)
        {
            Prognoza odabrana = null;
            foreach (Prognoza prognoza in prognoze)
            {
                if (prognoza.naziv_mesta == collection["Mesto"])
                {
                    odabrana = prognoza;
                    break;
                }
            }
            return View(odabrana);
        }
    }
}