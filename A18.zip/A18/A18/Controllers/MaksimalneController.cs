﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using A18.Models;
using System.IO;
using System.Data;

namespace A18.Controllers
{
    public class MaksimalneController : Controller
    {
        // GET: Maksimalne
        public ActionResult Ispis()
        {
            List<Prognoza> prognoze = new List<Prognoza>();
            DataSet data_set = new DataSet();
            using (StreamReader reader = new StreamReader(Server.MapPath("~/Xml_Files/Prognoza.xml")))
            {
                data_set.ReadXml(reader);
            }
            foreach (DataRow row in data_set.Tables[0].Rows)
            {
                prognoze.Add(new Prognoza(row));
            }
            return View(prognoze);
        }
    }
}