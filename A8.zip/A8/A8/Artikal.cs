﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;

namespace A8
{
    public class Artikal
    {
        public string sifra { get; set; }
        public string naziv { get; set; }
        public string proizvodjac { get; set; }
        public string ram_memorija { get; set; }
        public string tip_procesora { get; set; }
        public string slika { get; set; }
        public string kamera { get; set; }
        public float ekran { get; set; }
        public decimal cena { get; set; }

        public Artikal(string Upis)
        {
            this.sifra = Upis.Substring(0, 5).Trim();
            this.naziv = Upis.Substring(5, 25).Trim();
            this.proizvodjac = Upis.Substring(30, 20).Trim();
            this.ram_memorija = Upis.Substring(50, 5).Trim();
            this.tip_procesora = Upis.Substring(55, 15).Trim();
            this.kamera = Upis.Substring(70, 10).Trim();
            this.ekran = Convert.ToSingle(Upis.Substring(80, 5).Trim());
            this.slika = Upis.Substring(85, 30).Trim();
            this.cena = Convert.ToDecimal(Upis.Substring(115, 10).Trim());
        }
    }
}