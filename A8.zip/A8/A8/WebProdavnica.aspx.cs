﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Security.AccessControl;
using System.Drawing;

namespace A8
{
    public partial class WebProdavnica : System.Web.UI.Page
    {
        static List<Artikal> lista = new List<Artikal>();
        protected void Page_Load(object sender, EventArgs e)
        {
            SortedSet<string> proizvodjac, ram, procesor, kamera, ekran;
            proizvodjac = new SortedSet<string>();
            ram = new SortedSet<string>();
            procesor = new SortedSet<string>();
            kamera = new SortedSet<string>();
            ekran = new SortedSet<string>();
            if (!IsPostBack)
            {
                lista.Clear();
                using (StreamReader sr = File.OpenText(Server.MapPath("Artikli.txt")))
                {
                    string linija = sr.ReadLine();
                    while (linija != null)
                    {
                        lista.Add(new Artikal(linija));
                        linija = sr.ReadLine();
                    }
                }
                GridView1.DataSource = lista;
                GridView1.DataBind();
                foreach (Artikal artikal in lista)
                {
                    proizvodjac.Add(artikal.proizvodjac);
                    ram.Add(artikal.ram_memorija);
                    procesor.Add(artikal.tip_procesora);
                    kamera.Add(artikal.kamera);
                    ekran.Add(artikal.ekran.ToString());
                }
                DDLProizvodjac.DataSource = proizvodjac;
                DDLProizvodjac.DataBind();
                DDLRam.DataSource = ram;
                DDLRam.DataBind();
                DDLProcesor.DataSource = procesor;
                DDLProcesor.DataBind();
                DDLKamera.DataSource = kamera;
                DDLKamera.DataBind();
                DDLEkran.DataSource = ekran;
                DDLEkran.DataBind();
            }
        }

        protected void btnPretrazi_Click(object sender, EventArgs e)
        {
            List<Artikal> Ispis = new List<Artikal>();
            foreach (Artikal item in lista)
            {
                if (item.proizvodjac == DDLProizvodjac.SelectedValue.ToString() && item.ram_memorija == DDLRam.SelectedValue.ToString()
                    && item.tip_procesora == DDLProcesor.SelectedValue.ToString() && item.kamera == DDLKamera.SelectedValue.ToString()
                    && item.ekran == Convert.ToSingle(DDLEkran.SelectedValue))
                {
                    Ispis.Add(item);
                }
            }
            GridView1.DataSource = Ispis;
            GridView1.DataBind();
        }
    }
}