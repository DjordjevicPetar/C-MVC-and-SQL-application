﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;

namespace A13
{
    public partial class Katalog : System.Web.UI.Page
    {
        static List<CD> pesme = new List<CD>();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                pesme.Clear();
                using (StreamReader reader = new StreamReader(Server.MapPath("katalog.txt")))
                {
                    SortedSet<string> zanrovi = new SortedSet<string>();
                    SortedSet<int> godine_izdanja = new SortedSet<int>();
                    string line = reader.ReadLine();
                    while (line != null)
                    {
                        pesme.Add(new CD(line));
                        zanrovi.Add(pesme[pesme.Count - 1].zanr);
                        godine_izdanja.Add(pesme[pesme.Count - 1].godina_izdanja);
                        line = reader.ReadLine();
                    }
                    InputZanr.DataSource = zanrovi;
                    InputZanr.DataBind();
                    InputZanr.Items.Add("Sve");
                    InputGodina.DataSource = godine_izdanja;
                    InputGodina.DataBind();
                    InputGodina.Items.Add("Sve");
                    Tabela.DataSource = pesme;
                    Tabela.DataBind();
                }
            }
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            List<CD> ispis = new List<CD>();
            foreach (CD pesma in pesme)
            {
                bool bool_izvodjac = (InputIzvodjac.Text == null || pesma.izvodjac.Contains(InputIzvodjac.Text));
                bool bool_naziv = (InputNaziv.Text == null || pesma.naziv_albuma.Contains(InputNaziv.Text));
                bool bool_zanr = (InputZanr.Text == "Sve" || pesma.zanr == InputZanr.Text);
                bool bool_godina = (InputGodina.Text == "Sve" || pesma.godina_izdanja == Convert.ToInt32(InputGodina.Text));
                bool bool_izdavac = (InputIzdavac.Text == null || pesma.izdavacka_kuca.Contains(InputIzdavac.Text));
                if (bool_izvodjac && bool_naziv && bool_zanr && bool_godina && bool_izdavac)
                {
                    ispis.Add(pesma);
                }
                Tabela.DataSource = ispis;
                Tabela.DataBind();
            }
        }
    }
}