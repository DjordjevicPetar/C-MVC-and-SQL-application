﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace A13
{
    public class CD
    {
        public string izvodjac { get; set; }
        public string naziv_albuma { get; set; }
        public string zanr { get; set; }
        public int godina_izdanja { get; set; }
        public string izdavacka_kuca { get; set; }
        public string slika_omota { get; set; }
        public CD(string line)
        {
            string[] fields = line.Split('|');
            izvodjac = fields[0].Trim();
            naziv_albuma = fields[1].Trim();
            zanr = fields[2].Trim();
            godina_izdanja = Convert.ToInt32(fields[3].Trim());
            izdavacka_kuca = fields[4].Trim();
            slika_omota = fields[5].Trim();
        }
    }
}