﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace A6
{
    public class Pretplatnik
    {
        public string sifra { get; set; }
        public string ime { get; set; }
        public string prezime { get; set; }
        public string adresa { get; set; }
        public string mesto { get; set; }
        public string broj_telefona { get; set; }
        public string e_mail { get; set; }

        public Pretplatnik(string line)
        {
            string[] fields = line.Split('|');
            sifra = fields[0].Trim();
            ime = fields[1].Trim();
            prezime = fields[2].Trim();
            adresa = fields[3].Trim();
            mesto = fields[4].Trim();
            broj_telefona = fields[5].Trim();
            e_mail = fields[6].Trim();
        }
    }
}