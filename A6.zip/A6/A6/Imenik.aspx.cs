﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using Newtonsoft.Json.Serialization;
using System.ComponentModel.DataAnnotations;
using WebGrease.Configuration;

namespace A6
{
    public partial class Imenik : System.Web.UI.Page
    {
        static List<Pretplatnik> imenik = new List<Pretplatnik>();
        protected void Page_Load(object sender, EventArgs e)
        {
            SortedSet<string> DDLMesto = new SortedSet<string>();
            if (!IsPostBack)
            {
                imenik.Clear();
                using (StreamReader reader = new StreamReader(Server.MapPath("Imenik.txt")))
                {
                    string line = reader.ReadLine();
                    while (line != null)
                    {
                        imenik.Add(new Pretplatnik(line));
                        DDLMesto.Add(imenik[imenik.Count - 1].mesto);
                        line = reader.ReadLine();
                    }
                    DDLMesto.Add("Sve");
                    InputMesto.DataSource = DDLMesto;
                    InputMesto.DataBind();
                    GridView1.DataSource = imenik;
                    GridView1.DataBind();
                }
            }
        }

        protected void btnPretrazi_Click(object sender, EventArgs e)
        {
            List<Pretplatnik> rezultat = new List<Pretplatnik>();
            foreach (Pretplatnik pretplatnik in imenik)
            {
                bool bool_ime = (InputIme.Text == null) || (pretplatnik.ime.Contains(InputIme.Text));
                bool bool_prezime = (InputPrezime.Text == null) || (pretplatnik.prezime.Contains(InputPrezime.Text));
                bool bool_adresa = (InputAdresa.Text == null) || (pretplatnik.adresa.Contains(InputAdresa.Text));
                bool bool_mesto = (InputMesto.Text == "Sve") || (pretplatnik.mesto == InputMesto.Text);
                bool bool_broj = (InputBroj.Text == null) || (pretplatnik.broj_telefona.Contains(InputBroj.Text));
                if (bool_ime && bool_prezime && bool_adresa && bool_mesto && bool_broj)
                {
                    rezultat.Add(pretplatnik);
                }
            }
            GridView1.DataSource = rezultat;
            GridView1.DataBind();
        }
    }
}